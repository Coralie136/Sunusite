<?php
/*------------------------------------------------------------------------
# mod_smartcarousel.php(module)
# ------------------------------------------------------------------------
# version		1.0.0
# author    	Implantes en tu ciudad
# copyright 	Copyright (c) 2011 Top Position All rights reserved.
# @license 		http://www.gnu.org/licenses/gpl-2.0.html GNU/GPL
# Website		http://mastermarketingdigital.org/open-source-joomla-extensions

This module uses 	 

	 *	jQuery carouFredSel 6.2.0
	 *	Demo's and documentation:
	 *	caroufredsel.dev7studios.com
	 *
	 *	Copyright (c) 2013 Fred Heusschen
	 *	www.frebsite.nl
	 *
	 *	Dual licensed under the MIT and GPL licenses.
	 *	http://en.wikipedia.org/wiki/MIT_License
	 *	http://en.wikipedia.org/wiki/GNU_General_Public_License
 *

-------------------------------------------------------------------------
*/

// no direct access
defined('_JEXEC') or die;

$w = $params->get('width','900');
$h = $params->get('height','180');
$iw = $params->get('imgwidth','250');
$ih = $params->get('imgheight','150');
$scroll = $params->get('scroll','1');


$document->addStyleDeclaration( '
		
			.wrapper {
				text-align: center;
				width: '.$w.'px;
				margin: 0;
				padding: 0p;
				height: '.$h.'px;
				margin-left: auto;
				margin-right: auto;
			}
			
			.img-carousel{
				width:'.$iw.'px;
				height:'.$ih.'px;
				border:1px #e2e2e2 solid;
				background-color:#FFF;
				margin-right:20px;
				padding:5px;
				border-radius:4px;
			}
			
			.h1center{
				padding-bottom:25px;
			}
				
			
' );

$document->addScript(JURI::base().'/modules/mod_smartcarousel/assets/jquery.carouFredSel-6.2.0-packed.js');
$document->addScript(JURI::base().'/modules/mod_smartcarousel/assets/helper-plugins/jquery.mousewheel.min.js');
$document->addScript(JURI::base().'/modules/mod_smartcarousel/assets/helper-plugins/jquery.transit.min.js');
$document->addScript(JURI::base().'/modules/mod_smartcarousel/assets/helper-plugins/jquery.ba-throttle-debounce.min.js');

$directory = 'images/'.$params->get('myfolder','');


?>

		<script type="text/javascript" language="javascript">
			
			jQuery(function() {
				jQuery('#foo').carouFredSel({
					width   : <?php echo $w; ?>,

					auto: {
						pauseOnHover: 'resume',
						timeoutDuration:5000
							}
					}, {
					transition: true
				});
			});
			
		</script>


	<div class="wrapper">
        <div id="foo">
        	<?php 
		
			//echo $directory;
			
	
			foreach(glob($directory.'/*') as $filename){
			
				$ext = pathinfo($filename, PATHINFO_EXTENSION);
	
				if($ext=='jpg'||$ext=='jpeg'||$ext=='png'||$ext=='gif')  { 
					echo '<img class="img-carousel" src='.JURI::base().$directory.'/'.str_replace(' ', '%20', basename($filename)).' />';
				}
			}
			
			?>
        </div>
    </div>
    <div style="font-family:Verdana, Arial, Helvetica, sans-serif; font-size:10px; text-align:right; display:block; padding-right:10px;"><a href="http://mastermarketingdigital.org/">Master en redes sociales</a></div>